 <footer>
            <p>Barangay 599 E-Barangay Information Management System @2021</p>
        </footer>